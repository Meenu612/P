from flask import Flask, request, jsonify, render_template
import requests

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/favpicks')
def favpicks():
    return render_template('favPicks.html')

@app.route('/quiz')
def quiz():
    return render_template('quiz.html')

@app.route('/recommend-movies', methods=['POST'])
def recommend_movies():
    user_preferences = request.json
    genre_preference = user_preferences.get("genre")
    
    # Replace 'YOUR_API_KEY' with your actual API key
    api_url = f"http://www.omdbapi.com/?s={genre_preference}&apikey=e74cb19"

    try:
        response = requests.get(api_url)

        if response.status_code == 200:
            movie_data = response.json()
            movies = movie_data.get("Search", [])

            if movies:
                recommended_movie = movies[0]
            else:
                recommended_movie = {
                    "title": "No Matching Movies",
                    "description": "Sorry, no movies matching your preferences were found.",
                }

            return jsonify(recommended_movie)
        else:
            return jsonify({"error": "Failed to fetch movie data from the API"}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
