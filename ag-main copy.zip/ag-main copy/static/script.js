document.addEventListener("DOMContentLoaded", function () {
    const questionElement = document.getElementById("question");
    const optionsButton = document.getElementById("options-b");
    const nextButton = document.getElementById("nextbt");
    const movieContainer = document.getElementById("movieContainer");
    const generateButton = document.getElementById("generateButton");

    let currentQuestionIndex = 0;
    let userPreferences = {};

    function showQuestion() {
        resetState();
        const currentQuestion = quizQuestions[currentQuestionIndex];
        const questionNo = currentQuestionIndex + 1;
        questionElement.innerHTML = questionNo + ". " + currentQuestion.question;

        currentQuestion.options.forEach(option => {
            const button = document.createElement("button");
            button.innerHTML = option.text;
            button.classList.add("btnQ");
            optionsButton.appendChild(button);

            button.addEventListener("click", selectOption);
        });
    }

    function resetState() {
        nextButton.style.display = "block";
        movieContainer.style.display = "none";
        nextButton.removeEventListener("click", showMovieRecommendation);
        while (optionsButton.firstChild) {
            optionsButton.removeChild(optionsButton.firstChild);
        }
    }

    function selectOption(event) {
        const selectedOption = event.target.innerHTML;
        userPreferences[currentQuestionIndex] = selectedOption;
        currentQuestionIndex++;

        if (currentQuestionIndex < quizQuestions.length) {
            showQuestion();
        } else {
            showMovieRecommendation();
        }
    }

    function showMovieRecommendation() {
        const questionContainer = document.getElementById("quizContainer");
        questionContainer.style.display = "none";
        movieContainer.style.display = "block";

        fetch("/recommend-movies", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(userPreferences),
        })
            .then(response => response.json())
            .then(movie => {
                const movieTitleElement = document.getElementById("movieTitle");
                const movieDescriptionElement = document.getElementById("movieDescription");

                movieTitleElement.textContent = movie.title;
                movieDescriptionElement.textContent = movie.description;
            })
            .catch(error => {
                console.error("Error fetching movie recommendation:", error);
                alert("An error occurred while fetching the movie recommendation. Please try again later.");
            });
    }

    nextButton.addEventListener("click", function () {
        const selectedOption = document.querySelector('input[name="option"]:checked');

        if (selectedOption) {
            const currentQuestion = quizQuestions[currentQuestionIndex];
            userPreferences[currentQuestionIndex] = selectedOption.value;
            currentQuestionIndex++;

            if (currentQuestionIndex < quizQuestions.length) {
                showQuestion();
            } else {
                showMovieRecommendation();
            }
        } else {
            alert("Please select an option.");
        }
    });

    generateButton.addEventListener("click", function () {
        currentQuestionIndex = 0;
        userPreferences = {};
        const questionContainer = document.getElementById("quizContainer");
        questionContainer.style.display = "block";
        movieContainer.style.display = "none";
        showQuestion();
    });

    const quizQuestions = [
        {
            question: "What genre of movie do you prefer?",
            options: [
                { text: "Action" },
                { text: "Comedy" },
                { text: "Drama" },
                { text: "Sci-Fi" },
                { text: "Horror" },
                { text: "Romance" }
            ]
        },
        {
            question: "How long should the movie be?",
            options: [
                { text: "Short" },
                { text: "Medium" },
                { text: "Long" }
            ]
        },
        {
            question: "What rating should the movie have?",
            options: [
                { text: "G" },
                { text: "PG" },
                { text: "PG-13" },
                { text: "R" }
            ]
        },
        {
            question: "Which actor do you prefer?",
            options: [
                { text: "Tom Hanks" },
                { text: "Jennifer Lawrence" },
                { text: "Robert Downey Jr." },
                { text: "Meryl Streep" }
            ]
        },
        {
            question: "Which year should the movie be from?",
            options: [
                { text: "2000-2010" },
                { text: "2010-2020" },
                { text: "1990-2000" },
                { text: "1980-1990" }
            ]
        },
        {
            question: "Which director do you prefer?",
            options: [
                { text: "Christopher Nolan" },
                { text: "Quentin Tarantino" },
                { text: "Steven Spielberg" },
                { text: "Greta Gerwig" }
            ]
        },
        {
            question: "What type of setting do you prefer?",
            options: [
                { text: "City" },
                { text: "Countryside" },
                { text: "Fantasy World" },
                { text: "Space" }
            ]
        },
        {
            question: "What is your preferred movie language?",
            options: [
                { text: "English" },
                { text: "French" },
                { text: "Spanish" },
                { text: "Other" }
            ]
        }
    ];

    showQuestion();
});


